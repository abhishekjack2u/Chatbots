#!/usr/bin/env python
# coding: utf-8

# In[14]:


import nltk


# In[15]:


import numpy as np


# In[16]:


import random
import string


# In[17]:


import bs4 as bs
import urllib.request
import re


# ## Scraping data from tennis wiki website:

# In[18]:


raw_html=urllib.request.urlopen("https://en.wikipedia.org/wiki/Tennis")
raw_html=raw_html.read()


# ## Raw Data Looks like:

# In[19]:


raw_html


# ## Converting into HTML.

# In[20]:


article_html=bs.BeautifulSoup(raw_html,"lxml")


# In[21]:


article_html


# ## Sorting HTML file with the paragraph P.

# In[22]:


article_paragraphs=article_html.find_all("p")


# In[23]:


article_text=""


# In[24]:


article_paragraphs[1]


# In[25]:


for para in article_paragraphs:
    article_text += para.text


# ## converting all the alphabets into smaller case:

# In[26]:


article_text=article_text.lower()


# In[27]:


article_text


# ## Removing Symbols and numbers:

# In[28]:


article_text = re.sub(r'\[[0-9]*\]', ' ', article_text)
article_text = re.sub(r'\s+', ' ', article_text)


# In[29]:


article_text


# # Sentence Tokenization:

# In[30]:


article_sentences = nltk.sent_tokenize(article_text)
article_words = nltk.word_tokenize(article_text)


# In[31]:


article_sentences


# In[32]:


article_words


# # Lammetization:

# In[33]:


wnlemmatizer = nltk.stem.WordNetLemmatizer()


# In[34]:


def perform_lemmatization(tokens):
    return [wnlemmatizer.lemmatize(token) for token in tokens]


# # Removing Punctuation:

# In[35]:


punctuation_removal = dict((ord(punctuation), None) for punctuation in string.punctuation)

def get_processed_text(document):
    return perform_lemmatization(nltk.word_tokenize(document.lower().translate(punctuation_removal)))


# In[36]:


greeting_inputs = ("hey", "good morning", "good evening", "morning", "evening", "hi", "whatsup")
greeting_responses = ["hey", "hey hows you?", "*nods*", "hello, how you doing", "hello", "Welcome, I am good and you"]


# In[37]:


def generate_greeting_response(greeting):
    for token in greeting.split():
        if token.lower() in greeting_inputs:
            return random.choice(greeting_responses)


# # Term and inverse document frequency vectorization:

# In[38]:


from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# In[42]:


def generate_response(user_input):
    datatrainedbot_response = ''
    article_sentences.append(user_input)

    word_vectorizer = TfidfVectorizer(tokenizer=get_processed_text, stop_words='english')
    all_word_vectors = word_vectorizer.fit_transform(article_sentences)
    similar_vector_values = cosine_similarity(all_word_vectors[-1], all_word_vectors)
    similar_sentence_number = similar_vector_values.argsort()[0][-2]

    matched_vector = similar_vector_values.flatten()
    matched_vector.sort()
    vector_matched = matched_vector[-2]

    if vector_matched == 0:
        datatrainedbot_response = datatrainedbot_response + "I am sorry, I could not understand you"
        return datatrainedbot_response
    else:
        datatrainedbot_response = datatrainedbot_response + article_sentences[similar_sentence_number]
        return datatrainedbot_response


# In[ ]:


word_vectorizer = TfidfVectorizer(tokenizer=get_processed_text, stop_words='english')
all_word_vectors = word_vectorizer.fit_transform(article_sentences)



similar_vector_values = cosine_similarity(all_word_vectors[-1], all_word_vectors)


similar_sentence_number = similar_vector_values.argsort()[0][-2]


continue_dialogue = True
print("Hello, I am your friend DataTrained Bot. You can ask me any question regarding tennis:")
while(continue_dialogue == True):
    human_text = input("The bot is ready to answer: ")
    human_text = human_text.lower()
    if human_text != 'bye':
        if human_text == 'thanks' or human_text == 'thank you very much' or human_text == 'thank you':
            continue_dialogue = False
            print("DataTrained Bot: Most welcome")
        else:
            if generate_greeting_response(human_text) != None:
                print("DataTrained Bot: " + generate_greeting_response(human_text))
            else:
                print("DataTrained Bot: ", end="")
                print(generate_response(human_text))
                article_sentences.remove(human_text)
    else:
        continue_dialogue = False
        print("DataTrained Bot: Good bye and take care of yourself...Stay Safe In Covid!")


# In[ ]:




