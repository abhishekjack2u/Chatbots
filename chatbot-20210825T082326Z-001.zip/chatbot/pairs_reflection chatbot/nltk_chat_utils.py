from nltk.chat.util import Chat, reflections

pairs = [
    [
        r"my name is (.*)",
        ["Hello %1, How are you today ?",]
    ],
     [
        r"what is your name ?",
        ["My name is DataTrained Bot and I'm a chatbot ?",]
    ],
    [
        r"how are you ?",
        ["I'm doing good\nHow about You ?",]
    ],
    [
        r"sorry (.*)",
        ["I am only a %1 i never mind.",]
    ],
    [
        r"i'm (.*) doing good",
        ["Nice to hear that","Alright :)",]
    ],
    [
        r"hi|hey|hello",
        ["Hello", "Hey there",]
    ],
    [
        r"your age",
        ["I'm a computer program dude\nSeriously you are asking me this?",]
        
    ],
    [
        r"what (.*) want ?",
        ["Make me an offer I can't refuse. %1 can't give me anything.",]
        
    ],
    [
        r"created|invented|made|born",
        ["DataTrained created me using Python's NLTK library ","top secret ;)",]
    ],
    [
        r"(location|city)",
        ['The head office is in Bengaluru? Another office is in Noida. Refer to the below send URL for the address details.\n https://www.datatrained.com/contact-us',]
    ],
    [
        r"how is weather in (.*)?",
        ["Weather in %1 is awesome like always","Too hot man here in %1"]
    ],
    [
        r"i work in (.*)?",
        ["%1 is an Amazing company, I have heard about it.",]
    ],
[
        r"(.*)raining in (.*)",
        ["No rain since last week here in %2,"]
    ],
    [
        r"how (.*) health(.*)",
        ["I'm a computer program, so I'm always healthy ",]
    ],
    [
        r"(.*) (sports|game) ?",
        ["I'm a very big fan of Football",]
    ],
    [
        r"who (.*) sportsperson ?",
        ["Zlatan","Ronaldo","Beckham all time fav"]
],
    [
        r"moviestar|actor",
        ["Jhonny Depp"]
],
    [
        r"quit",
        ["BBye take care. See you soon :) ","It was nice talking to you. See you soon :)"]
],
    [
        r"Bye|tata",
        ["Bye it was nice talking to you.",]
],
    [
        r"Domain|you do|area of expertise|work|help me",
        ["We provide DataScience course along with the cloud computing. Refer to the below send URL for the courses offered by the datatrained institute.\n https://www.datatrained.com/#"]
],
    [
        r"placement|gurantee|jobs|after course|any placement",
        ["We provide 100 percent job gurantee. Refer to below send URL for the success stories of the company.\n https://www.datatrained.com/placements-at-datatrained"]
],
    [
        r"money back|no placement|refund",
        ["We provide 100 percent money back gurantee if not placed by our institute.\n(Except GST)"]
],
    [
        r"the contact|contact details|talk|mentor details|other queries|doubts|connect",
        ["Connect with the support team:\n +91 95600 84091"]
]
]
def bot():
    print("Hi, I'm DataTrained_Bot and I can provide support related to DataScience Course.")
    chat = Chat(pairs, reflections)
    chat.converse()
if __name__ == "__main__":
    bot()